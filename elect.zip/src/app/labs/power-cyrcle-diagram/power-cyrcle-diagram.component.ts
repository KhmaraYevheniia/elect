import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-power-cyrcle-diagram',
  templateUrl: './power-cyrcle-diagram.component.html',
  styleUrls: ['./power-cyrcle-diagram.component.scss']
})
export class PowerCyrcleDiagramComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
